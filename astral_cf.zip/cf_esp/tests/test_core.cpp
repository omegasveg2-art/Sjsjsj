// host test: builds a fake CounterFlame process image from offsets.h and runs the real Game/Il2 code on it.
// g++ -std=c++17 -I../src test_core.cpp ../src/il2cpp.cpp ../src/game.cpp ../src/mem.cpp -o test_core && ./test_core
#include "../src/game.h"
#include <cassert>
#include <cstdio>
#include <cstring>
#include <chrono>
#include <map>
#include <thread>

struct FakeMem : IMem {
    struct Chunk { std::vector<uint8_t> d; Region r; };
    std::map<uint64_t, Chunk> c;
    void alloc(uint64_t a, size_t n, bool w = true, const char* path = "") {
        Chunk ch; ch.d.assign(n, 0);
        ch.r.start = a; ch.r.end = a + n; ch.r.r = true; ch.r.w = w; ch.r.path = path;
        c[a] = std::move(ch);
    }
    uint8_t* at(uint64_t a, size_t n) {
        a = untag(a);
        auto it = c.upper_bound(a);
        if (it == c.begin()) return nullptr;
        --it;
        if (a < it->first || a + n > it->first + it->second.d.size()) return nullptr;
        return &it->second.d[a - it->first];
    }
    bool read(uint64_t a, void* out, size_t n) override {
        uint8_t* p = at(a, n);
        if (!p) { memset(out, 0, n); return false; }
        memcpy(out, p, n); return true;
    }
    bool write(uint64_t a, const void* in, size_t n) override { uint8_t* p = at(a, n); if (!p) return false; memcpy(p, in, n); return true; }
    std::vector<Region> regions() override { std::vector<Region> v; for (auto& k : c) v.push_back(k.second.r); return v; }
    template <class T> void w(uint64_t a, T v) { uint8_t* p = at(a, sizeof(T)); assert(p); memcpy(p, &v, sizeof(T)); }
    void wstr(uint64_t a, const char* s) { uint8_t* p = at(a, strlen(s) + 1); assert(p); memcpy(p, s, strlen(s) + 1); }
};

static int fails = 0;
#define CHECK(x) do { if (!(x)) { printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #x); fails++; } } while (0)

int main() {
    // ---- w2s sanity (left-handed, forward +Z, right +X)
    {
        Cam c; c.pos = {0, 0, 0}; c.fwd = {0, 0, 1}; c.fovY = 90;
        float x, y;
        CHECK(w2s(c, {0, 0, 10}, 1920, 1080, x, y) && fabsf(x - 960) < 1e-3 && fabsf(y - 540) < 1e-3);
        CHECK(w2s(c, {10, 0, 10}, 1920, 1080, x, y) && x > 960);              // +X is right
        CHECK(w2s(c, {0, 10, 10}, 1920, 1080, x, y) && fabsf(y - 0) < 1e-2);  // fov 90 vertical: +10 at z=10 is top edge
        CHECK(!w2s(c, {0, 0, -5}, 1920, 1080, x, y));
        c.fwd = {1, 0, 0};                                                    // turned right: old +Z point is now on the left
        CHECK(w2s(c, {10, 0, 5}, 1920, 1080, x, y) && x > 960 == false ? true : (w2s(c, {10, 0, -5}, 1920, 1080, x, y) && x < 960));
    }

    // ---- fake process
    FakeMem m;
    const uint64_t BASE = 0x7100000000ull, KL = 0x7200000000ull, META = 0x7300000000ull, HEAP = 0x7400000000ull;
    m.alloc(BASE + 0x39C0000, 0x10000, true, "/data/app/x/lib/arm64/libil2cpp.so");
    m.alloc(KL, 0x4000);
    m.alloc(META, 0x1000, false, "/data/app/x/assets/bin/Data/Managed/Metadata/global-metadata.dat");
    m.alloc(HEAP, 0x20000);

    // metadata strings
    uint64_t sCull = META + 0x10, sFps = META + 0x40, sLife = META + 0x70, sEmpty = META + 0x100, sNsGame = META + 0x110, sNsLife = META + 0x140;
    m.wstr(sCull, "PlayerCulling"); m.wstr(sFps, "PlayerFPSCamera"); m.wstr(sLife, "LifeState");
    m.wstr(sEmpty, ""); m.wstr(sNsGame, "ScarletWork.Game"); m.wstr(sNsLife, "ScarletWork.Game.Life");
    // preceding NULs are already there (zero-init) -> "\0Name\0" matches

    auto mkclass = [&](uint64_t k, uint64_t name, uint64_t ns, uint64_t statics) {
        m.w<uint64_t>(k + 0x10, name); m.w<uint64_t>(k + 0x18, ns); m.w<uint64_t>(k + 0x78, k); m.w<uint64_t>(k + 0xB8, statics);
    };
    uint64_t kCull = KL + 0x000, kFps = KL + 0x400, kLife = KL + 0x800;
    uint64_t stCull = HEAP + 0x100, stFps = HEAP + 0x200;
    mkclass(kCull, sCull, sEmpty, stCull);
    mkclass(kFps, sFps, sNsGame, stFps);
    mkclass(kLife, sLife, sNsLife, 0);
    // TypeInfo slots (cull with a TAGGED pointer like scudo would produce, life slot left empty -> scan path)
    m.w<uint64_t>(BASE + off::PlayerCulling::cls.typeinfo_rva, kCull | (0xb4ull << 56));
    m.w<uint64_t>(BASE + off::PlayerFPSCamera::cls.typeinfo_rva, kFps);

    // camera
    m.w<uint8_t>(stCull + off::PlayerCulling::s__hasCamera, 1);
    m.w<Vec3>(stCull + off::PlayerCulling::s__cameraPosition, {0, 1.6f, 0});
    m.w<Vec3>(stCull + off::PlayerCulling::s__cameraForward, {0, 0, 1});
    uint64_t fpsLocal = HEAP + 0x300;
    m.w<uint64_t>(stFps + off::PlayerFPSCamera::s_Local, fpsLocal);
    m.w<float>(fpsLocal + off::PlayerFPSCamera::BaseFieldOfView, 75.f);

    // players: List<PlayerCulling> at HEAP+0x1000, array at +0x1100
    uint64_t lst = HEAP + 0x1000, arr = HEAP + 0x1100;
    m.w<uint64_t>(stCull + off::PlayerCulling::s_Instances, lst);
    m.w<uint64_t>(lst + il2::LIST_ITEMS, arr | (0xb4ull << 56)); m.w<uint32_t>(lst + il2::LIST_SIZE, 3);
    m.w<uint32_t>(arr + il2::ARR_LEN, 8);
    struct P { int actor; bool mine; bool death; Vec3 pos; const char* nick; int hp; uint8_t team; bool alive; } ps[3] = {
        {1, true,  false, {1, 0, 1},  "me",    100, 1, true},
        {2, false, false, {0, 0, 20}, "Enemy", 73,  2, true},
        {3, false, true,  {5, 0, 9},  "Dead",  0,   1, false},
    };
    for (int i = 0; i < 3; i++) {
        uint64_t base = HEAP + 0x2000 + i * 0x800;
        uint64_t cull = base, ctrl = base + 0x100, net = base + 0x200, view = base + 0x400, pl = base + 0x500, nick = base + 0x600;
        m.w<uint64_t>(arr + il2::ARR_DATA + i * 8, cull);
        m.w<uint64_t>(cull + off::PlayerCulling::_controller, ctrl);
        m.w<uint64_t>(cull + off::PlayerCulling::_network, net);
        m.w<uint64_t>(ctrl + off::PlayerController::_view, view);
        m.w<uint64_t>(ctrl + off::PlayerController::_player, pl);
        m.w<uint8_t>(ctrl + off::PlayerController::_isDeath, ps[i].death);
        m.w<uint8_t>(view + off::PhotonView::IsMine, ps[i].mine);
        m.w<uint32_t>(view + off::PhotonView::ownerActorNr, ps[i].actor);
        m.w<Vec3>(net + off::PlayerNetwork::networkPosition, ps[i].pos);
        m.w<double>(net + off::PlayerNetwork::_receivedServerTime, 100.0);
        m.w<uint8_t>(net + off::PlayerNetwork::_appliedBools, i == 1 ? 2 : 0);   // enemy crouching
        m.w<uint64_t>(pl + off::Player::nickName, nick);
        size_t L = strlen(ps[i].nick);
        m.w<uint32_t>(nick + il2::STR_LEN, (uint32_t)L);
        for (size_t k = 0; k < L; k++) m.w<uint16_t>(nick + il2::STR_CHARS + k * 2, (uint16_t)ps[i].nick[k]);
    }
    // LifeState instance + entries
    uint64_t life = HEAP + 0x8000, llist = HEAP + 0x8100, larr = HEAP + 0x8200;
    m.w<uint64_t>(life, kLife);
    m.w<uint64_t>(life + off::LifeState::_entries, llist);
    m.w<uint64_t>(llist + il2::LIST_ITEMS, larr); m.w<uint32_t>(llist + il2::LIST_SIZE, 3);
    m.w<uint32_t>(larr + il2::ARR_LEN, 4);
    for (int i = 0; i < 3; i++) {
        uint64_t e = larr + il2::ARR_DATA + i * off::LifeEntrySize;
        m.w<int32_t>(e + off::LifeEntry::Actor, ps[i].actor);
        m.w<int32_t>(e + off::LifeEntry::Health, ps[i].hp);
        m.w<uint8_t>(e + off::LifeEntry::Alive, ps[i].alive);
        m.w<uint8_t>(e + off::LifeEntry::Team, ps[i].team);
    }
    // decoy: an object-looking word equal to kLife with an empty entries list must be rejected
    m.w<uint64_t>(HEAP + 0x9000, kLife);

    Game g(m, BASE);
    CHECK(g.resolve());
    Snapshot s;
    CHECK(g.update(s));
    CHECK(s.valid && s.lifeOk && s.haveLocal);
    CHECK(s.localActor == 1 && s.localTeam == 1);
    CHECK(fabsf(s.cam.fovY - 75.f) < 1e-4);
    CHECK(s.players.size() == 3);
    if (s.players.size() == 3) {
        CHECK(s.players[1].actor == 2 && s.players[1].hp == 73 && s.players[1].team == 2 && s.players[1].crouch);
        CHECK(std::string(s.players[1].name) == "Enemy");
        CHECK(s.players[2].dead);
        float x, y;
        CHECK(w2s(s.cam, s.players[1].pos + Vec3{0, 1.7f, 0}, 2400, 1080, x, y));
        printf("enemy head on screen: %.1f %.1f\n", x, y);
    }
    // ---- weapon mods: found by name scan (no TypeInfo slot), zeroed, restored
    {
        uint64_t sWp = META + 0x200;
        m.wstr(sWp, "WeaponParameters");
        uint64_t kWp = KL + 0xC00, wp = HEAP + 0x6000, rp = HEAP + 0x6400;
        mkclass(kWp, sWp, sEmpty, 0);
        m.w<uint64_t>(wp, kWp);
        m.w<float>(wp + off::WeaponParameters::_pelletSpread, 2.5f);
        m.w<float>(wp + off::WeaponParameters::_scopedMoveInaccuracy, 1.5f);
        m.w<uint64_t>(wp + off::WeaponParameters::_recoilParameters, rp);
        m.w<float>(rp + off::RecoilParameters::_verticalRange, 3.f);
        m.w<float>(rp + off::RecoilParameters::_horizontalRange, 1.f);
        m.w<float>(rp + off::RecoilParameters::cameraDeviationCoeff, 0.5f);
        g.set_scan_gap(0);
        g.patch_weapons(true, true, true);                    // noSway is now independent of noSpread -- pass it explicitly
        float v; m.read(rp + off::RecoilParameters::_verticalRange, &v, 4); CHECK(v == 0.f);
        m.read(wp + off::WeaponParameters::_pelletSpread, &v, 4); CHECK(v == 0.f);
        m.read(wp + off::WeaponParameters::_scopedMoveInaccuracy, &v, 4); CHECK(v == 0.f);
        CHECK(g.weapons() == 1 && g.patched() == 5);
        g.patch_weapons(false, false, false);                 // throttled (1 s) -> still patched right away
        std::this_thread::sleep_for(std::chrono::milliseconds(1100));
        g.patch_weapons(true, false, false);                 // spread off again -> only spread restored
        m.read(wp + off::WeaponParameters::_pelletSpread, &v, 4); CHECK(v == 2.5f);
        m.read(rp + off::RecoilParameters::_verticalRange, &v, 4); CHECK(v == 0.f);
        std::this_thread::sleep_for(std::chrono::milliseconds(1100));
        g.patch_weapons(false, false);
        m.read(rp + off::RecoilParameters::_verticalRange, &v, 4); CHECK(v == 3.f);
        CHECK(g.patched() == 0);
    }
    // ---- bomb: planted, timer from the server clock, position from _blastPosition; carried -> owner
    {
        uint64_t sBM = META + 0x380, sB = META + 0x3C0, kBM = KL + 0x1600, kB = KL + 0x1800, bm = HEAP + 0xD000, bomb = HEAP + 0xD400;
        m.wstr(sBM, "BombManager"); m.wstr(sB, "Bomb");
        mkclass(kBM, sBM, sEmpty, 0); mkclass(kB, sB, sEmpty, 0);
        m.w<uint64_t>(bm, kBM); m.w<uint64_t>(bomb, kB);
        m.w<uint64_t>(bm + off::BombManager::_bomb, bomb);
        m.w<uint32_t>(bm + off::BombManager::_bombOwnerId, 2);
        m.w<uint8_t>(bm + off::BombManager::_plantedThisRound, 0);
        g.set_scan_gap(0);
        Snapshot sb; CHECK(g.update(sb));
        CHECK(sb.bomb.state == 1 && sb.bomb.owner == 2);                  // carried
        m.w<uint8_t>(bm + off::BombManager::_plantedThisRound, 1);
        m.w<uint8_t>(bomb + off::Bomb::_isActive, 1);
        m.w<double>(bomb + off::Bomb::_explodeAt, 140.0);
        m.w<uint8_t>(bomb + off::Bomb::_blastPosition, 1);
        m.w<Vec3>(bomb + off::Bomb::_blastPosition + 4, Vec3{5, 1, 7});
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        CHECK(g.update(sb));
        CHECK(sb.bomb.state == 2 && sb.bomb.hasPos && fabsf(sb.bomb.pos.x - 5.f) < 1e-4 && fabsf(sb.bomb.remaining - 40.f) < 0.01f);
        m.w<uint8_t>(bm + off::BombManager::_defusedThisRound, 1);
        CHECK(g.update(sb)); CHECK(sb.bomb.state == 0);
        printf("bomb: ok\n");
    }
    // ---- movement mods (tuning object + convars + statics + velocity), all reversible
    {
        uint64_t sMv = META + 0x240, sTun = META + 0x2C0, sCore = META + 0x300, sCv = META + 0x340;
        uint64_t kMv = KL + 0xD00, kTun = KL + 0x1000, kCore = KL + 0x1200, kCv = KL + 0x1400;
        uint64_t mv = HEAP + 0x7000, mvSt = HEAP + 0x7800, tun = HEAP + 0xC000, core = HEAP + 0xC400, cvSt = HEAP + 0xC800;
        m.wstr(sMv, "PlayerMovement"); m.wstr(sTun, "SourceMovementTuning"); m.wstr(sCore, "SourceGameMovement"); m.wstr(sCv, "MovementConVars");
        mkclass(kMv, sMv, sEmpty, mvSt); mkclass(kTun, sTun, sEmpty, 0); mkclass(kCore, sCore, sEmpty, 0); mkclass(kCv, sCv, sEmpty, cvSt);
        m.w<uint64_t>(mv, kMv); m.w<uint64_t>(tun, kTun); m.w<uint64_t>(core, kCore);
        m.w<uint64_t>(mv + off::PlayerMovement::_movement, tun);
        m.w<uint64_t>(mv + off::PlayerMovement::_core, core);
        m.w<float>(tun + off::SourceMovementTuning::MaxSpeed, 100.f);
        m.w<float>(tun + off::SourceMovementTuning::BunnyJumpMaxSpeedFactor, 1.2f);
        m.w<float>(cvSt + off::MovementConVars::s_JumpImpulse, 7.5f);
        m.w<float>(mv + off::PlayerMovement::_wishStick, 0.f); m.w<float>(mv + off::PlayerMovement::_wishStick + 4, 1.f);
        m.w<float>(mv + off::PlayerMovement::_gravityScale, 1.f);
        m.w<uint64_t>(HEAP + 0x2000 + 0x100 + off::PlayerController::_movementController, mv);   // local player's controller
        Snapshot s2; CHECK(g.update(s2));                                                       // refreshes localMove_
        g.set_scan_gap(0);
        MoveCfg mc; mc.bhop = true; mc.noclip = true; mc.speed = 2.f; mc.jump = 1.5f;
        g.drive_move(mc, s2);
        float v; uint8_t b;
        m.read(tun + off::SourceMovementTuning::MaxSpeed, &v, 4); CHECK(v == 200.f);
        m.read(tun + off::SourceMovementTuning::BunnyJumpMaxSpeedFactor, &v, 4); CHECK(v == 100.f);
        m.read(cvSt + off::MovementConVars::s_JumpImpulse, &v, 4); CHECK(fabsf(v - 7.5498347f * 1.5f) < 1e-3);
        m.read(mvSt + off::PlayerMovement::s_AutoBunnyHopping, &b, 1); CHECK(b == 1);
        m.read(mvSt + off::PlayerMovement::s_EnableBunnyHopping, &b, 1); CHECK(b == 1);
        m.read(mv + off::PlayerMovement::NoclipEnabled, &b, 1); CHECK(b == 1);
        std::this_thread::sleep_for(std::chrono::milliseconds(300));
        g.drive_move(MoveCfg(), s2);                                                            // everything off -> originals back
        m.read(tun + off::SourceMovementTuning::MaxSpeed, &v, 4); CHECK(v == 100.f);
        m.read(tun + off::SourceMovementTuning::BunnyJumpMaxSpeedFactor, &v, 4); CHECK(fabsf(v - 1.2f) < 1e-6);
        m.read(cvSt + off::MovementConVars::s_JumpImpulse, &v, 4); CHECK(v == 7.5f);
        m.read(mvSt + off::PlayerMovement::s_AutoBunnyHopping, &b, 1); CHECK(b == 0);
        m.read(mv + off::PlayerMovement::NoclipEnabled, &b, 1); CHECK(b == 0);
        CHECK(g.move_patched() == 0);
        // fly: gravity scale 0 and velocity along the camera
        MoveCfg fc; fc.fly = true; fc.flySpeed = 10.f;
        std::this_thread::sleep_for(std::chrono::milliseconds(300));
        g.drive_move(fc, s2);
        float vel[3]; m.read(core + off::SourceGameMovement::Velocity, vel, 12);
        CHECK(fabsf(sqrtf(vel[0] * vel[0] + vel[1] * vel[1] + vel[2] * vel[2]) - 10.f) < 0.05f);
        m.read(mv + off::PlayerMovement::_gravityScale, &v, 4); CHECK(v == 0.f);
        std::this_thread::sleep_for(std::chrono::milliseconds(300));
        g.drive_move(MoveCfg(), s2);
        m.read(mv + off::PlayerMovement::_gravityScale, &v, 4); CHECK(v == 1.f);
        printf("move diag: %s\n", g.move_diag().c_str());
    }
    // ---- code patches via il2cpp method table + silent detour on the fake process
    {
        uint64_t sArms = META + 0x280;
        m.wstr(sArms, "ArmsController");
        uint64_t kArms = KL + 0xE00, mtab = HEAP + 0x9000 + 0x1000, code = BASE + 0x39C4000;
        mkclass(kArms, sArms, sEmpty, HEAP + 0xA800);
        const char* names[3] = {"ApplyCameraRecoil", "GetRelativeDispertion", "FireRay"};
        uint8_t np[3] = {1, 4, 4};
        m.w<uint64_t>(kArms + il2::K_METHODS, mtab);
        m.w<uint16_t>(kArms + il2::K_MCOUNT, 3);
        for (int i = 0; i < 3; i++) {
            uint64_t mi = HEAP + 0xB000 + i * 0x100, nm = HEAP + 0xB800 + i * 0x40;
            m.w<uint64_t>(mtab + i * 8, mi);
            m.w<uint64_t>(mi + il2::MI_PTR, code + i * 0x100);
            m.w<uint64_t>(mi + il2::MI_NAME, nm);
            m.w<uint8_t>(mi + il2::MI_NPARAMS, np[i]);
            m.wstr(nm, names[i]);
            m.w<uint32_t>(code + i * 0x100, 0xA9BF7BFDu);              // stp x29, x30, [sp, #-16]!
        }
        g.set_scan_gap(0);
        Il2 il(m, BASE);
        uint64_t k = il.klass(off::ArmsController::cls);
        CHECK(k == kArms);
        CHECK(il.method_addr(k, "FireRay", 4) == code + 0x200);
        CHECK(il.method_addr(k, "FireRay", 3) == 0);                    // wrong parameter count is refused
        CHECK(il.method_addr(k, "ApplyCameraRecoil") == code);
        g.patch_code(true, true);                                      // data-only now: game code must stay untouched
        uint32_t v; m.read(code, &v, 4); CHECK(v == 0xA9BF7BFDu);
        m.read(code + 0x100, &v, 4); CHECK(v == 0xA9BF7BFDu);
        CHECK(g.code_patched() == 0);
        // silent: needs a zero padding cave inside a libil2cpp r-x mapping
        g.silent_prepare(true);
        CHECK(std::string(g.silent_status()).rfind("err_", 0) == 0 || std::string(g.silent_status()) == "FireRay_not_found" || std::string(g.silent_status()) == "ok_ray_only");
        printf("silent status on the fake image: %s\n", g.silent_status());
        g.shutdown_patches();
        m.read(code + 0x100, &v, 4); CHECK(v == 0xA9BF7BFDu);
    }
    printf(fails ? "%d FAILED\n" : "all ok\n", fails);
    return fails != 0;
}
