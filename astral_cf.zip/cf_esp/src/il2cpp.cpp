#include "il2cpp.h"
#include <cstring>
#include <algorithm>
#include <ctime>

std::string Il2::cstr(uint64_t a, size_t max) {
    char buf[128] = {0};
    if (max > 127) max = 127;
    if (!plausible_ptr(a)) return {};
    // may straddle into an unmapped page: retry shorter
    for (size_t n = max; n >= 8; n /= 2)
        if (m_.read(a, buf, n)) { buf[n] = 0; return std::string(buf); }
    return {};
}

std::string Il2::str(uint64_t s, size_t maxchars) {
    std::string out;
    if (!plausible_ptr(s)) return out;
    uint32_t len = rd32(m_, s + il2::STR_LEN);
    if (len == 0 || len > 256) return out;
    len = (uint32_t)std::min<size_t>(len, maxchars);
    uint16_t w[64] = {0};
    if (!m_.read(s + il2::STR_CHARS, w, len * 2)) return out;
    for (uint32_t i = 0; i < len; i++) out.push_back(w[i] >= 32 && w[i] < 127 ? (char)w[i] : '?');
    return out;
}

bool Il2::list(uint64_t l, uint64_t& items, uint32_t& size, uint32_t maxsize) {
    if (!plausible_ptr(l)) return false;
    items = rdp(m_, l + il2::LIST_ITEMS);
    size = rd32(m_, l + il2::LIST_SIZE);
    if (size > maxsize) return false;
    if (size && !plausible_ptr(items)) return false;
    if (size && rd32(m_, items + il2::ARR_LEN) < size) return false;
    return true;
}

bool Il2::klass_ok(uint64_t k, const ClassRef& c) {
    if (!plausible_ptr(k)) return false;
    if (rdp(m_, k + il2::K_SELF) != k) return false;                // Il2CppClass::klass points to itself
    if (cstr(rdp(m_, k + il2::K_NAME)) != c.name) return false;
    return cstr(rdp(m_, k + il2::K_NS)) == c.ns;
}

uint64_t Il2::klass(const ClassRef& c) {
    if (c.typeinfo_rva) {
        uint64_t k = rdp(m_, base_ + c.typeinfo_rva);
        if (klass_ok(k, c)) return k;
    }
    return scan_klass(c);   // patch moved the slot / slot not filled yet
}

// Full scan: every Il2CppClass has `klass` (self pointer) at +0x78, so a qword at address A equal to A-0x78 marks a class.
// Independent of the TypeInfo RVAs (game updates) and of how the metadata file is mapped. Cached; rescanned at most every 8 s.
static double mono_now() {
    timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

void Il2::scan_all() {
    byName_.clear(); seen_ = 0;
    std::vector<uint8_t> buf;
    for (auto& r : m_.regions()) {
        if (!r.r || !r.w) continue;
        if (!r.path.empty() && r.path[0] != '[') continue;          // anon / [heap] / [anon:...] only
        if (r.end - r.start > (2048ull << 20)) continue;
        for (uint64_t a = r.start; a < r.end; a += 4u << 20) {
            size_t n = (size_t)std::min<uint64_t>(r.end - a, 4u << 20);
            buf.resize(n);
            if (!m_.read(a, buf.data(), n)) continue;
            for (size_t i = 0; i + 8 <= n; i += 8) {
                uint64_t v;
                memcpy(&v, &buf[i], 8);
                v = untag(v);
                if (v != a + i - il2::K_SELF) continue;
                uint64_t k = v;
                std::string nm = cstr(rdp(m_, k + il2::K_NAME)), ns = cstr(rdp(m_, k + il2::K_NS));
                if (nm.empty() || nm.size() > 90) continue;
                bool ok = true;
                for (char ch : nm) if ((unsigned char)ch < 32 || (unsigned char)ch > 126) { ok = false; break; }
                if (!ok) continue;
                seen_++;
                byName_[ns + std::string(1, '\0') + nm] = k;
            }
        }
    }
}

uint64_t Il2::scan_klass(const ClassRef& c) {
    std::string key = std::string(c.ns) + std::string(1, '\0') + c.name;
    auto it = byName_.find(key);
    if (it != byName_.end() && klass_ok(it->second, c)) return it->second;
    double t = mono_now();
    if (t < nextScan_) return 0;
    scan_all();
    nextScan_ = mono_now() + gap_;
    it = byName_.find(key);
    return it != byName_.end() && klass_ok(it->second, c) ? it->second : 0;
}

uint64_t Il2::method_addr(uint64_t k, const char* name, int nparams) {
    if (!plausible_ptr(k)) return 0;
    uint64_t arr = rdp(m_, k + il2::K_METHODS);
    uint32_t n = rdv<uint16_t>(m_, k + il2::K_MCOUNT);
    if (!plausible_ptr(arr) || n == 0 || n > 4000) return 0;
    std::vector<uint64_t> mi(n);
    if (!m_.read(arr, mi.data(), n * 8)) return 0;
    for (uint32_t i = 0; i < n; i++) {
        uint64_t m = untag(mi[i]);
        if (!plausible_ptr(m)) continue;
        if (cstr(rdp(m_, m + il2::MI_NAME), 64) != name) continue;
        if (nparams >= 0 && rd8(m_, m + il2::MI_NPARAMS) != (uint8_t)nparams) continue;
        uint64_t f = rdp(m_, m + il2::MI_PTR);
        if (plausible_ptr(f)) return f;
    }
    return 0;
}

std::vector<uint64_t> Il2::find_instances(uint64_t klass, const std::function<bool(uint64_t)>& accept) {
    std::vector<uint64_t> out;
    std::vector<uint8_t> buf;
    for (auto& r : m_.regions()) {
        if (!r.r || !r.w) continue;
        if (!r.path.empty() && r.path[0] != '[') continue;
        if (r.end - r.start > (1024ull << 20)) continue;
        for (uint64_t a = r.start; a < r.end; a += 4u << 20) {
            size_t n = (size_t)std::min<uint64_t>(r.end - a, 4u << 20);
            buf.resize(n);
            if (!m_.read(a, buf.data(), n)) continue;
            for (size_t i = 0; i + 8 <= n; i += 8) {
                uint64_t v;
                memcpy(&v, &buf[i], 8);
                if (untag(v) == klass && accept(a + i)) out.push_back(a + i);
            }
        }
    }
    return out;
}
