// code patching of the running game through /proc/<pid>/mem (root): `ret` patches and the silent-aim detour.
// arm64 only (the encodings below are A64); everything is reversible, originals are kept.
#pragma once
#include "mem.h"
#include "vmath.h"
#include <map>
#include <string>
#include <vector>

class CodePatcher {
public:
    explicit CodePatcher(IMem& m) : m_(m) {}
    bool patch(uint64_t addr, const void* bytes, size_t n);      // remembers the original bytes, verifies by read-back
    void restore(uint64_t addr);
    void restore_all();
    bool has(uint64_t addr) const { return orig_.count(addr) != 0; }
    void adopt(uint64_t addr, const void* origBytes, size_t n);   // register an original we did not write ourselves (patch left by an earlier run)
    size_t count() const { return orig_.size(); }
    bool ret_at(uint64_t addr);                                  // function body becomes `ret` (void functions)
private:
    IMem& m_;
    std::map<uint64_t, std::vector<uint8_t>> orig_;
    std::map<uint64_t, std::vector<uint8_t>> put_;     // what we wrote: restore only when the memory still holds exactly this
};

// A64 encoders (public for the host test)
namespace a64 {
inline uint32_t b(uint64_t from, uint64_t to) { return 0x14000000u | (uint32_t)(((int64_t)(to - from) >> 2) & 0x03FFFFFF); }
inline uint32_t ldr_lit(uint32_t opc, uint32_t rt, uint64_t from, uint64_t to) { return opc | ((uint32_t)(((int64_t)(to - from) >> 2) & 0x7FFFF) << 5) | rt; }
inline uint32_t ldr_x(uint32_t rt, uint64_t f, uint64_t t) { return ldr_lit(0x58000000u, rt, f, t); }
inline uint32_t ldr_w(uint32_t rt, uint64_t f, uint64_t t) { return ldr_lit(0x18000000u, rt, f, t); }
inline uint32_t ldr_s(uint32_t rt, uint64_t f, uint64_t t) { return ldr_lit(0x1C000000u, rt, f, t); }
inline uint32_t cbz_w(uint32_t rt, uint64_t f, uint64_t t) { return 0x34000000u | ((uint32_t)(((int64_t)(t - f) >> 2) & 0x7FFFF) << 5) | rt; }
inline uint32_t b_hi(uint64_t f, uint64_t t) { return 0x54000008u | ((uint32_t)(((int64_t)(t - f) >> 2) & 0x7FFFF) << 5); }
inline uint32_t adr(uint32_t rd, uint64_t f, uint64_t t) { int64_t d = (int64_t)(t - f); return 0x10000000u | ((uint32_t)(d & 3) << 29) | ((uint32_t)((d >> 2) & 0x7FFFF) << 5) | rd; }
constexpr uint32_t MRS_X9_CNTVCT = 0xD53BE049u, CMP_X9_X10 = 0xEB0A013Fu, RET = 0xD65F03C0u, NOP = 0xD503201Fu;
constexpr uint32_t LDR_W12_X13 = 0xB94001ACu, ADD_W12_W12_1 = 0x1100058Cu, STR_W12_X13 = 0xB90001ACu;
}

// Detour of `FireRay(this, Vector3 camPos, Vector3 forward, ...)` (3 floats replaced: s3..s5) and
// `FirePellets(this, params, Vector3 origin, Quaternion aim, ...)` (4 floats: s3..s6). The cave lives in zero padding of libil2cpp's
// text, holds the data words too (cf_core refreshes them), and the replacement is only active until `deadline` (counter ticks),
// so if cf_core dies the game falls back to normal shots by itself.
class SilentHook {
public:
    SilentHook(IMem& m, CodePatcher& cp) : m_(m), cp_(cp) {}
    bool install(uint64_t func, int nfloats, std::string& err);   // false + reason
    void feed(const float* v, uint64_t deadline);                  // writes values, then deadline, then enable
    void off();                                                    // enable = 0
    bool ready() const { return cave_ != 0; }
    uint64_t cave() const { return cave_; }
    uint32_t hits();                                               // how many calls the detour really redirected (counter inside the cave)
    void uninstall();
    // cave image (public for the host test); returns false when the function's first instruction cannot be relocated
    static bool build(uint64_t cave, uint64_t func, uint32_t firstInsn, int nfloats, std::vector<uint8_t>& out, std::string& err);
    static constexpr uint32_t DEADLINE = 0x40, ENABLE = 0x48, VALS = 0x4C, HITS = 0x5C, RELOC = 0x60, ORIGW = 0x68, SIZE = 0x70, ORIGSLOT = 0x38;
private:
    IMem& m_;
    CodePatcher& cp_;
    uint64_t cave_ = 0, func_ = 0;
    int nf_ = 3;
    bool enabled_ = false;
};

uint64_t counter_now();       // cntvct_el0 (arm64) / steady clock ns elsewhere
uint64_t counter_freq();      // cntfrq_el0 (arm64) / 1e9 elsewhere
// unit quaternion (x,y,z,w) that looks along dir (Unity: left-handed, Y up, roll 0)
void look_quat(Vec3 dir, float q[4]);
