package cf.esp;

import java.util.ArrayList;

/** Pure Java (no android imports): protocol parser, camera prediction, world-to-screen. Unit-tested on the host. */
final class Player {
    int actor, team, hp, flags;
    float x, y, z, vx, vy, vz;
    String name = "";
    boolean local() { return (flags & 1) != 0; }
    boolean dead() { return (flags & 2) != 0; }
    boolean crouch() { return (flags & 4) != 0; }
    boolean mate() { return (flags & 8) != 0; }
}

final class Snap {
    boolean ok;
    String status = "";
    float cx, cy, cz, fx, fy, fz, fov = 60f;
    int localTeam;
    String info = "";              // aim diagnostics from the core (touch mode, learned px/deg, locked actor)
    int lock;                       // actor the aimbot is locked on, 0 = none
    int silHits;                    // shots fired while the silent detour was armed (from "sil=status/N")
    Player[] players = new Player[0];
    int bombState, bombOwner;       // 0 none, 1 carried, 2 planted
    boolean bombHas;                // bomb world position known
    float bx, by, bz, bombRem = -1f;
    // derived by Model.publish
    long t, tData;                  // nanoTime of this line / of the last time the camera really changed
    float yaw, pitch;               // rad
    float yawRate, pitchRate;       // rad/s (smoothed)
    float vcx, vcy, vcz;            // camera velocity, units/s (smoothed)
}

final class Model {
    static volatile Snap snap = status("starting");

    static Snap status(String s) {
        Snap n = new Snap();
        n.status = s.length() > 90 ? s.substring(0, 90) : s;
        n.t = n.tData = System.nanoTime();
        return n;
    }

    private static float[] floats(String s, int n) {
        String[] p = s.split(",", -1);
        if (p.length != n) return null;
        float[] r = new float[n];
        for (int i = 0; i < n; i++) r[i] = Float.parseFloat(p[i]);
        return r;
    }

    /** S|status|cx,cy,cz|fx,fy,fz|fov|localTeam|actor,team,hp,flags,x,y,z,vx,vy,vz,name;...   or   N|status */
    static Snap parse(String line) {
        if (line.startsWith("N|")) return status(line.substring(2));
        try {
            String[] f = line.split("\\|", -1);
            if (f.length < 7 || !f[0].equals("S")) return status(line);
            float[] c = floats(f[2], 3), d = floats(f[3], 3);
            if (c == null || d == null) return status("bad line");
            Snap s = new Snap();
            s.ok = true;
            s.status = f[1];
            s.cx = c[0]; s.cy = c[1]; s.cz = c[2];
            s.fx = d[0]; s.fy = d[1]; s.fz = d[2];
            s.fov = Float.parseFloat(f[4]);
            s.localTeam = Integer.parseInt(f[5]);
            s.t = s.tData = System.nanoTime();
            float fl = (float) Math.sqrt(s.fx * s.fx + s.fy * s.fy + s.fz * s.fz);
            if (fl > 1e-6f) {
                s.yaw = (float) Math.atan2(s.fx, s.fz);
                s.pitch = (float) Math.asin(Math.max(-1f, Math.min(1f, s.fy / fl)));
            }
            ArrayList<Player> ps = new ArrayList<>();
            if (!f[6].isEmpty()) {
                for (String e : f[6].split(";")) {
                    String[] q = e.split(",", 11);
                    if (q.length < 11) continue;
                    Player p = new Player();
                    p.actor = Integer.parseInt(q[0]);
                    p.team = Integer.parseInt(q[1]);
                    p.hp = Integer.parseInt(q[2]);
                    p.flags = Integer.parseInt(q[3]);
                    p.x = Float.parseFloat(q[4]); p.y = Float.parseFloat(q[5]); p.z = Float.parseFloat(q[6]);
                    p.vx = Float.parseFloat(q[7]); p.vy = Float.parseFloat(q[8]); p.vz = Float.parseFloat(q[9]);
                    p.name = q[10];
                    ps.add(p);
                }
            }
            s.players = ps.toArray(new Player[0]);
            if (f.length >= 8) {
                s.info = f[7];
                int i = s.info.indexOf("lock=");
                if (i >= 0) {
                    int e = s.info.indexOf(' ', i);
                    try { s.lock = Integer.parseInt(s.info.substring(i + 5, e < 0 ? s.info.length() : e)); } catch (NumberFormatException ignored) { }
                }
                int si = s.info.indexOf("sil=");
                if (si >= 0) {
                    int slash = s.info.indexOf('/', si);
                    int e2 = s.info.indexOf(' ', si);
                    if (slash >= 0 && (e2 < 0 || slash < e2)) {
                        try { s.silHits = Integer.parseInt(s.info.substring(slash + 1, e2 < 0 ? s.info.length() : e2)); } catch (NumberFormatException ignored) { }
                    }
                }
            }
            if (f.length >= 9) {
                String[] q = f[8].split(",", -1);
                if (q.length >= 7) {
                    try {
                        s.bombState = Integer.parseInt(q[0]); s.bombHas = q[1].equals("1");
                        s.bx = Float.parseFloat(q[2]); s.by = Float.parseFloat(q[3]); s.bz = Float.parseFloat(q[4]);
                        s.bombRem = Float.parseFloat(q[5]); s.bombOwner = Integer.parseInt(q[6].trim());
                    } catch (NumberFormatException ignored) { s.bombState = 0; }
                }
            }
            return s;
        } catch (NumberFormatException e) {
            return status("parse error: " + line);
        }
    }

    private static float wrap(float a) {
        final float P = (float) Math.PI;
        while (a > P) a -= 2 * P;
        while (a < -P) a += 2 * P;
        return a;
    }

    private static float clamp(float v, float m) { return v > m ? m : v < -m ? -m : v; }

    /**
     * Publishes a parsed snapshot. The core polls faster than the game refreshes the camera, so most lines are repeats:
     * rates are only recomputed when the camera really changed, and tData keeps the time of that last real change.
     */
    static void publish(Snap n) {
        Snap p = snap;
        boolean changedCam = true;
        if (n.ok && p.ok) {
            boolean same = Math.abs(n.cx - p.cx) < 1e-5f && Math.abs(n.cy - p.cy) < 1e-5f && Math.abs(n.cz - p.cz) < 1e-5f
                    && Math.abs(n.fx - p.fx) < 1e-6f && Math.abs(n.fy - p.fy) < 1e-6f && Math.abs(n.fz - p.fz) < 1e-6f;
            // a snap (aimbot flick, respawn, teleport) must not be extrapolated: zero the rates so the ESP does not fly past
            boolean jump = Math.abs(wrap(n.yaw - p.yaw)) > 0.35f || Math.abs(n.pitch - p.pitch) > 0.35f
                    || Math.abs(n.cx - p.cx) + Math.abs(n.cz - p.cz) > 4f;
            changedCam = !same;
            if (jump) {
                n.yawRate = n.pitchRate = 0f; n.vcx = n.vcy = n.vcz = 0f;
            } else if (same) {
                n.tData = p.tData; n.yawRate = p.yawRate; n.pitchRate = p.pitchRate;
                n.vcx = p.vcx; n.vcy = p.vcy; n.vcz = p.vcz;
            } else {
                float dt = (n.t - p.tData) / 1e9f;
                if (dt > 0.002f && dt < 0.2f) {
                    final float a = 0.7f;
                    n.yawRate = a * clamp(wrap(n.yaw - p.yaw) / dt, 30f) + (1 - a) * p.yawRate;
                    n.pitchRate = a * clamp((n.pitch - p.pitch) / dt, 30f) + (1 - a) * p.pitchRate;
                    n.vcx = a * clamp((n.cx - p.cx) / dt, 25f) + (1 - a) * p.vcx;
                    n.vcy = a * clamp((n.cy - p.cy) / dt, 25f) + (1 - a) * p.vcy;
                    n.vcz = a * clamp((n.cz - p.cz) / dt, 25f) + (1 - a) * p.vcz;
                }
            }
        }
        histPush(n, changedCam);
        snap = n;
    }

    // ---- camera history: the overlay usually runs AHEAD of the game picture (game output is ~2 frames behind its own memory),
    // so a negative display offset must show an older camera. Ring of the last camera changes, interpolated on demand.
    private static final int HN = 32;
    private static final long[] hT = new long[HN];
    private static final float[] hX = new float[HN], hY = new float[HN], hZ = new float[HN], hYaw = new float[HN], hPit = new float[HN];
    private static int hCount = 0, hHead = 0;

    private static synchronized void histPush(Snap n, boolean changed) {
        if (!n.ok) { hCount = 0; return; }
        if (!changed && hCount > 0) return;
        float yaw = n.yaw;
        if (hCount > 0) { int l = (hHead - 1 + HN) % HN; yaw = hYaw[l] + wrap(n.yaw - hYaw[l]); }
        hT[hHead] = n.t; hX[hHead] = n.cx; hY[hHead] = n.cy; hZ[hHead] = n.cz; hYaw[hHead] = yaw; hPit[hHead] = n.pitch;
        hHead = (hHead + 1) % HN;
        if (hCount < HN) hCount++;
    }

    private static void fwd(float yaw, float pitch, float[] out, int o) {
        float cp = (float) Math.cos(pitch);
        out[o] = cp * (float) Math.sin(yaw); out[o + 1] = (float) Math.sin(pitch); out[o + 2] = cp * (float) Math.cos(yaw);
    }

    /** out = {cx,cy,cz,fx,fy,fz}: the camera as it was (or, for the future, will be) at nanoTime tq. */
    static synchronized void camAt(Snap s, long tq, float[] out) {
        if (hCount == 0) { predictCam(s, 0f, out); return; }
        int last = (hHead - 1 + HN) % HN;
        if (tq >= hT[last]) { predictCam(s, Math.min(0.1f, (tq - hT[last]) / 1e9f), out); return; }
        int i = last;
        for (int k = 1; k < hCount; k++) {
            int p = (i - 1 + HN) % HN;
            if (hT[p] <= tq) {
                long span = hT[i] - hT[p];
                float a = span <= 0 ? 1f : Math.max(0f, Math.min(1f, (tq - hT[p]) / (float) span));
                out[0] = hX[p] + (hX[i] - hX[p]) * a; out[1] = hY[p] + (hY[i] - hY[p]) * a; out[2] = hZ[p] + (hZ[i] - hZ[p]) * a;
                fwd(hYaw[p] + (hYaw[i] - hYaw[p]) * a, hPit[p] + (hPit[i] - hPit[p]) * a, out, 3);
                return;
            }
            i = p;
        }
        out[0] = hX[i]; out[1] = hY[i]; out[2] = hZ[i];            // older than everything we kept: the oldest sample
        fwd(hYaw[i], hPit[i], out, 3);
    }

    /** out = {cx,cy,cz,fx,fy,fz}: camera moved forward in time by dt seconds using the smoothed rates. */
    static void predictCam(Snap s, float dt, float[] out) {
        float yaw = s.yaw + s.yawRate * dt;
        float pitch = Math.max(-1.55f, Math.min(1.55f, s.pitch + s.pitchRate * dt));
        float cp = (float) Math.cos(pitch);
        out[0] = s.cx + s.vcx * dt; out[1] = s.cy + s.vcy * dt; out[2] = s.cz + s.vcz * dt;
        out[3] = cp * (float) Math.sin(yaw); out[4] = (float) Math.sin(pitch); out[5] = cp * (float) Math.cos(yaw);
    }

    /** effective VERTICAL fov in degrees; optionally treat the game's number as horizontal. */
    static float effFov(float fov, float scale, boolean horiz, float aspect) {
        float f = fov * scale;
        if (!horiz) return f;
        double h = Math.toRadians(f);
        return (float) Math.toDegrees(2.0 * Math.atan(Math.tan(h * 0.5) / aspect));
    }

    /** Unity: left-handed, +Y up. right = up x fwd, roll ignored. c = {cx,cy,cz,fx,fy,fz}. out = {x, y}. */
    static boolean w2s(float[] c, float fovV, float wx, float wy, float wz, float W, float H, float[] out) {
        float fl = (float) Math.sqrt(c[3] * c[3] + c[4] * c[4] + c[5] * c[5]);
        if (fl < 1e-6f) return false;
        float fx = c[3] / fl, fy = c[4] / fl, fz = c[5] / fl;
        float rx = fz, rz = -fx;                                   // cross((0,1,0), f)
        float rl = (float) Math.sqrt(rx * rx + rz * rz);
        if (rl < 1e-6f) return false;
        rx /= rl; rz /= rl;
        float ux = fy * rz, uy = fz * rx - fx * rz, uz = -fy * rx; // cross(f, r), r.y = 0
        float dx = wx - c[0], dy = wy - c[1], dz = wz - c[2];
        float z = dx * fx + dy * fy + dz * fz;
        if (z < 0.05f) return false;
        float t = (float) Math.tan(Math.toRadians(fovV * 0.5));
        float aspect = W / H;
        out[0] = W * 0.5f + ((dx * rx + dz * rz) / (z * t * aspect)) * W * 0.5f;
        out[1] = H * 0.5f - ((dx * ux + dy * uy + dz * uz) / (z * t)) * H * 0.5f;
        return true;
    }

    /** convenience for tests: uses the snapshot's own camera and fov*scale (vertical). */
    static boolean w2s(Snap s, float fovScale, float wx, float wy, float wz, float W, float H, float[] out) {
        return w2s(new float[]{s.cx, s.cy, s.cz, s.fx, s.fy, s.fz}, s.fov * fovScale, wx, wy, wz, W, H, out);
    }
}
