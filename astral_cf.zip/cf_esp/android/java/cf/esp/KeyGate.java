package cf.esp;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.util.concurrent.TimeUnit;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * offline license check, no backend: key = base32( expiryDays(4) | nonce(4) | hmac[:6] ), HMAC-SHA256
 * over (expiryDays|nonce) with the secret below. tools/keygen.py issues keys with the same secret.
 * first successful check on a device binds the key to that device's ANDROID_ID hash locally
 * (SharedPreferences) so a reinstall keeps working but pasting the same key on a second phone
 * fails -- this is a soft bind (local only, no server to revoke/re-issue from), not real HWID
 * enforcement; a repacked APK with this class stripped bypasses everything, that's what Anti.java
 * is for, and neither stops someone with jadx and twenty minutes. fine for a sold-in-telegram
 * cheat, not a DRM.
 */
final class KeyGate {
    private static final String PREFS = "astral_lic";

    // secret split + XOR'd so it doesn't sit as one grep-able string in the dex/strings table.
    // rebuild it yourself when you regen keys: change MASK and the two halves together, then
    // regenerate tools/keygen.py's SECRET to match (see that file's comment).
    private static final byte MASK = (byte) 0x5A;
    private static final byte[] S1 = {0x3a, 0x02, 0x63, 0x58, 0x7d, 0x0d, 0x60, 0x5c};
    private static final byte[] S2 = {0x29, 0x1a, 0x7b, 0x49, 0x6e, 0x12, 0x71, 0x4f};

    private static byte[] secret() {
        byte[] out = new byte[S1.length + S2.length];
        for (int i = 0; i < S1.length; i++) out[i] = (byte) (S1[i] ^ MASK);
        for (int i = 0; i < S2.length; i++) out[S1.length + i] = (byte) (S2[i] ^ MASK);
        return out;
    }

    static final class Result {
        final boolean ok;
        final String reason; // "ok" | "format" | "bad_key" | "expired" | "device_mismatch"
        final long expiryEpochDay;
        Result(boolean ok, String reason, long exp) { this.ok = ok; this.reason = reason; this.expiryEpochDay = exp; }
    }

    private static final char[] ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567".toCharArray();

    private static byte[] base32Decode(String s) {
        s = s.replace("-", "").replace(" ", "").toUpperCase(java.util.Locale.US);
        int[] idx = new int[256];
        java.util.Arrays.fill(idx, -1);
        for (int i = 0; i < ALPHABET.length; i++) idx[ALPHABET[i]] = i;
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        int buf = 0, bits = 0;
        for (char c : s.toCharArray()) {
            int v = c < 256 ? idx[c] : -1;
            if (v < 0) continue; // skip padding/junk chars
            buf = (buf << 5) | v;
            bits += 5;
            if (bits >= 8) { bits -= 8; out.write((buf >> bits) & 0xFF); }
        }
        return out.toByteArray();
    }

    private static String deviceHash(Context ctx) {
        try {
            String aid = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ANDROID_ID);
            if (aid == null) aid = "no-android-id";
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(aid.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "no-android-id";
        }
    }

    static Result check(Context ctx, String rawKey) {
        if (rawKey == null) return new Result(false, "format", 0);
        String key = rawKey.trim();
        if (key.toUpperCase(java.util.Locale.US).startsWith("ASTRAL-")) key = key.substring(7);
        byte[] payload = base32Decode(key);
        if (payload.length != 14) return new Result(false, "format", 0);

        ByteBuffer bb = ByteBuffer.wrap(payload);
        int expiryDays = bb.getInt();
        byte[] signed = new byte[8];
        System.arraycopy(payload, 0, signed, 0, 8);
        byte[] mac8 = new byte[8];
        try {
            Mac m = Mac.getInstance("HmacSHA256");
            m.init(new SecretKeySpec(secret(), "HmacSHA256"));
            byte[] full = m.doFinal(signed);
            System.arraycopy(full, 0, mac8, 0, 6);
        } catch (Exception e) {
            return new Result(false, "bad_key", 0);
        }
        boolean macOk = true;
        for (int i = 0; i < 6; i++) if (payload[8 + i] != mac8[i]) macOk = false;
        if (!macOk) return new Result(false, "bad_key", 0);

        long today = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis());
        if (expiryDays != 0 && today > expiryDays) return new Result(false, "expired", expiryDays);

        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String keyHash = sha256Hex(rawKey.trim());
        String boundDevice = sp.getString("dev_" + keyHash, null);
        String here = deviceHash(ctx);
        if (boundDevice == null) {
            sp.edit().putString("dev_" + keyHash, here).putString("last_key", rawKey.trim()).putLong("last_exp", expiryDays).apply();
        } else if (!boundDevice.equals(here)) {
            return new Result(false, "device_mismatch", expiryDays);
        }
        return new Result(true, "ok", expiryDays);
    }

    /** re-validate the last-accepted key on this device without prompting again, e.g. on every app launch. */
    static boolean quickCheck(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String last = sp.getString("last_key", null);
        if (last == null) return false;
        return check(ctx, last).ok;
    }

    private static String sha256Hex(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return s;
        }
    }
}
