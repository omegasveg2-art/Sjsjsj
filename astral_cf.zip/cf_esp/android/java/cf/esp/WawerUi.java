package cf.esp;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;

/** Wawer menu: dark rounded window, sidebar tabs, cards with toggles / sliders / choices. Built from plain views. */
final class WawerUi {
    interface Host { void changed(); void close(); void unload(); }

    static final int BG = 0xF20E0A16, CARD = 0xFF171222, EDGE = 0xFF2B2440, ACCENT = 0xFFB388FF, TEXT = 0xFFEDE8F7, DIM = 0xFF958FAB, OFF = 0xFF3A3450;
    static final String[] TABS = {"Aimbot", "Rage", "Silent", "ESP", "Visuals", "Camera", "Misc", "Config"};

    final LinearLayout root;
    final View header;
    private final Context c;
    private final Host h;
    private final LinearLayout sidebar;
    private final ScrollView scroll;
    private int tab = 0, flip;
    private TextView statusV;
    private LinearLayout colA, colB;

    WawerUi(Context ctx, Host host) {
        c = ctx; h = host;
        root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(rounded(BG, EDGE, 16, 1));
        root.setPadding(dp(12), dp(10), dp(12), dp(12));

        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Astral.exe", 20, TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setLetterSpacing(0.04f);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = text("✕", 14, DIM);                      // square close button
        close.setGravity(Gravity.CENTER);
        close.setBackground(rounded(0xFF1D2127, EDGE, 8, 1));
        close.setOnClickListener(v -> h.close());
        head.addView(close, new LinearLayout.LayoutParams(dp(30), dp(30)));
        header = head;
        statusV = text("", 10.5f, DIM);
        statusV.setPadding(dp(2), dp(2), 0, dp(6));
        root.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(statusV, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout body = new LinearLayout(c);
        body.setOrientation(LinearLayout.HORIZONTAL);
        sidebar = new LinearLayout(c);
        sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setPadding(0, dp(10), dp(10), 0);
        ScrollView sideScroll = new ScrollView(c);
        sideScroll.setVerticalScrollBarEnabled(false);
        sideScroll.addView(sidebar);
        body.addView(sideScroll, new LinearLayout.LayoutParams(dp(112), ViewGroup.LayoutParams.MATCH_PARENT));
        scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        body.addView(scroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        root.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        select(tab);
    }

    // ------------------------------------------------------------------ helpers
    private int dp(float v) { return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable rounded(int fill, int stroke, float radiusDp, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(Math.max(1, dp(strokeDp)), stroke);
        return g;
    }

    private TextView text(String t, float sp, int col) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(col);
        v.setIncludeFontPadding(false);
        return v;
    }

    // ------------------------------------------------------------------ tabs
    private void select(int i) {
        tab = i;
        sidebar.removeAllViews();
        for (int t = 0; t < TABS.length; t++) {
            final int idx = t;
            LinearLayout item = new LinearLayout(c);
            item.setOrientation(LinearLayout.HORIZONTAL);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(8), 0, dp(8), 0);
            boolean on = t == tab;
            if (on) item.setBackground(rounded(0xFF1C2127, 0, 9, 0));
            View bar = new View(c);
            bar.setBackground(rounded(on ? ACCENT : 0, 0, 2, 0));
            item.addView(bar, new LinearLayout.LayoutParams(dp(3), dp(16)));
            TextView tv = text(TABS[t], 13, on ? TEXT : DIM);
            tv.setPadding(dp(10), 0, 0, 0);
            item.addView(tv);
            item.setOnClickListener(v -> select(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
            lp.bottomMargin = dp(2);
            sidebar.addView(item, lp);
        }
        rebuild();
    }

    private void rebuild() {
        scroll.removeAllViews();
        LinearLayout cols = new LinearLayout(c);
        cols.setOrientation(LinearLayout.HORIZONTAL);
        colA = new LinearLayout(c); colA.setOrientation(LinearLayout.VERTICAL);
        colB = new LinearLayout(c); colB.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams la = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        la.rightMargin = dp(5);
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lb.leftMargin = dp(5);
        cols.addView(colA, la);
        cols.addView(colB, lb);
        scroll.addView(cols);
        flip = 0;
        Snap sn = Model.snap;
        statusV.setText(sn.ok ? "core ok  \u00b7  " + sn.players.length + " players" + (sn.info.contains("sil=ok") ? "  \u00b7  silent ready" : "") : "core: " + sn.status);
        statusV.setTextColor(sn.ok ? 0xFF4ADE80 : 0xFFFFB86B);
        switch (tab) {
            case 0: tabAim(); break;
            case 1: tabRage(); break;
            case 2: tabSilent(); break;
            case 3: tabPlayers(); break;
            case 4: tabVisuals(); break;
            case 5: tabCamera(); break;
            case 6: tabMisc(); break;
            default: tabConfig();
        }
    }

    private LinearLayout card(String title) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(CARD, EDGE, 12, 1));
        card.setPadding(dp(4), dp(8), dp(4), dp(6));
        TextView t = text(title, 11, DIM);
        t.setPadding(dp(10), 0, dp(10), dp(4));
        card.addView(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(10);
        ((flip++ % 2 == 0) ? colA : colB).addView(card, lp);
        return card;
    }

    private LinearLayout row(LinearLayout card, String label, View right) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(6), dp(10), dp(6));
        r.addView(text(label, 12.5f, TEXT), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(right);
        card.addView(r, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return r;
    }

    private static final class Toggle extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();
        boolean on;
        Toggle(Context c, boolean on) { super(c); this.on = on; }
        @Override protected void onMeasure(int w, int hh) {
            float d = getResources().getDisplayMetrics().density;
            setMeasuredDimension((int) (38 * d), (int) (21 * d));
        }
        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), hh = getHeight();
            p.setColor(on ? ACCENT : OFF);
            rf.set(0, 0, w, hh);
            cv.drawRoundRect(rf, hh / 2, hh / 2, p);
            p.setColor(Color.WHITE);
            cv.drawCircle(on ? w - hh / 2 : hh / 2, hh / 2, hh / 2 - 2.5f * getResources().getDisplayMetrics().density, p);
        }
    }

    private void toggle(LinearLayout card, String label, String key) {
        Toggle t = new Toggle(c, Cfg.b(key));
        View r = row(card, label, t);
        View.OnClickListener l = v -> { t.on = !t.on; t.invalidate(); Cfg.set(key, t.on ? 1f : 0f); h.changed(); };
        r.setOnClickListener(l);
        t.setOnClickListener(l);
    }

    private void slider(LinearLayout card, String label, String key, float min, float max) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(2));
        LinearLayout top = new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.addView(text(label, 12.5f, TEXT), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final String fmt = (max - min) >= 50f ? "%.0f" : (max - min) >= 5f ? "%.1f" : "%.2f";
        TextView val = text(String.format(Locale.US, fmt, Cfg.f(key)), 12, ACCENT);
        top.addView(val);
        box.addView(top);
        SeekBar sb = new SeekBar(c);
        sb.setMax(1000);
        sb.setProgress(Math.round((Cfg.f(key) - min) / (max - min) * 1000f));
        sb.setProgressTintList(ColorStateList.valueOf(ACCENT));
        sb.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(OFF));
        sb.setPadding(dp(8), dp(4), dp(8), dp(4));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int pr, boolean user) {
                float v = min + (max - min) * pr / 1000f;
                Cfg.set(key, v);
                val.setText(String.format(Locale.US, fmt, v));
                if (user) h.changed();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(sb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(26)));
        card.addView(box, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void choice(LinearLayout card, String label, String key, String[] opts) {
        TextView v = text(opts[Math.max(0, Math.min(opts.length - 1, Cfg.i(key)))] + "  ▾", 12, TEXT);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10), dp(5), dp(10), dp(5));
        v.setBackground(rounded(0xFF1D2127, EDGE, 8, 1));
        View.OnClickListener l = x -> {
            int n = (Cfg.i(key) + 1) % opts.length;
            Cfg.set(key, n);
            v.setText(opts[n] + "  ▾");
            h.changed();
        };
        v.setOnClickListener(l);
        row(card, label, v).setOnClickListener(l);
    }

    private void color(LinearLayout card, String label, String key, int[] palette) {
        View sw = new View(c);
        sw.setBackground(rounded(palette[Math.max(0, Math.min(palette.length - 1, Cfg.i(key)))], Color.WHITE, 7, 1));
        View.OnClickListener l = x -> {
            int n = (Cfg.i(key) + 1) % palette.length;
            Cfg.set(key, n);
            sw.setBackground(rounded(palette[n], Color.WHITE, 7, 1));
            h.changed();
        };
        sw.setOnClickListener(l);
        LinearLayout r = row(card, label, sw);
        sw.setLayoutParams(new LinearLayout.LayoutParams(dp(24), dp(24)));
        r.setOnClickListener(l);
    }

    private void button(LinearLayout card, String label, Runnable run) {
        TextView b = text(label, 13, TEXT);
        b.setGravity(Gravity.CENTER);
        b.setBackground(rounded(0xFF1D2127, EDGE, 9, 1));
        b.setOnClickListener(v -> run.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
        lp.setMargins(dp(8), dp(4), dp(8), dp(4));
        card.addView(b, lp);
    }

    private void note(LinearLayout card, String t) {
        TextView v = text(t, 11, DIM);
        v.setPadding(dp(10), dp(2), dp(10), dp(4));
        card.addView(v);
    }

    // ------------------------------------------------------------------ tab contents
    private static final String[] KEYS = {"Always", "Vol Down", "Vol Up"};

    private void tabAim() {
        LinearLayout a = card("AIMBOT");
        toggle(a, "Enable", "aim");
        choice(a, "Key", "aimKey", KEYS);
        choice(a, "Target", "bone", new String[]{"Head", "Body", "Legs"});
        choice(a, "Mode", "aimMode", new String[]{"Smooth", "Snap"});
        slider(a, "FOV", "aimFov", 40f, 600f);
        slider(a, "Speed", "aimSmooth", 0.05f, 0.9f);
        toggle(a, "Team check", "teamCheck");
        toggle(a, "Show FOV circle", "showFov");
        Snap s = Model.snap;
        note(a, s.info.isEmpty() ? "Hold the key to aim." : "core: " + s.info);
        LinearLayout af = card("AUTO FIRE");
        toggle(af, "Enable", "trig");
        slider(af, "Radius (px)", "trigPx", 8f, 120f);
        slider(af, "Delay (ms)", "trigMs", 0f, 150f);
        slider(af, "Fire button X", "fx", 0.5f, 0.98f);
        slider(af, "Fire button Y", "fy", 0.2f, 0.95f);
        note(af, "Taps the fire button with a virtual finger while an enemy is under the crosshair. Set X/Y on your fire button.");
        button(a, Cfg.b("adv") ? "Advanced  [-]" : "Advanced  [+]", () -> { Cfg.set("adv", Cfg.b("adv") ? 0f : 1f); rebuild(); });
        if (Cfg.b("adv")) {
            LinearLayout t = card("ADVANCED");
            slider(t, "Max step (px)", "maxStep", 5f, 120f);
            slider(t, "Start px / degree", "ppd", 2f, 30f);
            slider(t, "Target lead (ms)", "lead", 0f, 150f);
            toggle(t, "Invert Y", "invY");
            slider(t, "Finger start X", "sx", 0.3f, 0.95f);
            slider(t, "Finger start Y", "sy", 0.15f, 0.85f);
            note(t, "px / degree is learned live; this is only the starting value.");
        }
    }

    private void tabRage() {
        LinearLayout m = card("RAGE MODE");
        toggle(m, "Enable", "rage");
        note(m, "A separate target-selection / correction profile on top of the aimbot above. Turning this on does NOT change the Aimbot tab's own settings -- Aim must still be on and its key held for rage to fire through it.");
        choice(m, "Priority", "ragePriority", new String[]{"Closest to crosshair", "Lowest HP", "Closest distance"});
        toggle(m, "Bone fallback (head->body->legs)", "rageBoneFallback");
        toggle(m, "Head only", "rageHeadOnly");
        toggle(m, "Instant snap (no smoothing)", "rageInstant");
        toggle(m, "Ignore aim FOV (within max distance)", "rageIgnoreFov");
        toggle(m, "No target hysteresis (always re-pick)", "rageNoHysteresis");
        LinearLayout af = card("RAGE AUTO FIRE");
        toggle(af, "Enable (own radius/delay)", "rageAutoFire");
        slider(af, "Radius (px)", "rageTrigPx", 4f, 100f);
        slider(af, "Delay (ms)", "rageTrigMs", 0f, 100f);
        note(af, "Independent of the Aimbot tab's Auto Fire -- tune this tighter/faster for rage without touching your casual settings.");
        LinearLayout fx = card("FEEDBACK");
        toggle(fx, "Vibrate on new lock", "rageVibrate");
        slider(fx, "Vibration (ms)", "rageVibrateMs", 10f, 150f);
        toggle(fx, "Hitmarker on silent hit", "rageHitmarker");
        color(fx, "FOV circle color", "rageFovCol", Cfg.ENEMY);
        note(fx, "The lock snapline/LOCK tag on the target box is already drawn whenever anything is locked (rage or not) -- nothing extra to toggle for that. These are drawn/played by the overlay itself, not the core.");
    }

    private void tabSilent() {
        LinearLayout si = card("SILENT AIM");
        toggle(si, "Enable", "silent");
        choice(si, "Key", "silentKey", KEYS);
        slider(si, "Silent FOV", "silentFov", 40f, 700f);
        toggle(si, "Show FOV circle", "showFov");
        choice(si, "Target", "bone", new String[]{"Head", "Body", "Legs"});
        toggle(si, "Team check", "teamCheck");
        note(si, "Your view does not move: every shot is sent at the target inside the silent FOV (red circle). The game's FireRay / FirePellets are redirected in memory while the key is held.");
        Snap s = Model.snap;
        LinearLayout st = card("STATUS");
        String sil = "not reported";
        int i = s.info.indexOf("sil=");
        if (i >= 0) { int e = s.info.indexOf(' ', i); sil = s.info.substring(i + 4, e < 0 ? s.info.length() : e); }
        note(st, "silent: " + sil + "  (ok/N = installed / shots fired while armed)");
        note(st, "If it says FireRay_not_found or err_*, the detour could not be installed and shots stay normal.");
    }

    private void tabPlayers() {
        LinearLayout b = card("WALLHACK / BOX");
        toggle(b, "ESP (wallhack)", "esp");
        note(b, "This already draws through walls -- it's an overlay, not the game's own renderer, so occlusion never matters. \"ESP\" and \"wallhack\" are the same toggle here.");
        choice(b, "Style", "boxStyle", new String[]{"Full", "Corner"});
        toggle(b, "Chams-style fill", "chams");
        toggle(b, "Glow", "glow");
        toggle(b, "Head dot", "headDot");
        LinearLayout i = card("INFO");
        toggle(i, "Health bar", "health");
        toggle(i, "HP text", "hpText");
        toggle(i, "Name", "name");
        toggle(i, "Distance", "dist");
        toggle(i, "Snaplines", "snap");
        toggle(i, "Off-screen arrows", "offscreen");
        toggle(i, "Hide teammates", "teamCheck");
        LinearLayout col = card("COLORS");
        color(col, "Enemy", "enemyCol", Cfg.ENEMY);
        color(col, "Team", "teamCol", Cfg.TEAM);
    }

    private void tabVisuals() {
        LinearLayout wd = card("WORLD");
        toggle(wd, "Bomb ESP (carrier, timer)", "bombEsp");
        toggle(wd, "Enemy counter pill", "hud");
        LinearLayout o = card("OVERLAY");
        toggle(o, "Radar", "radar");
        slider(o, "Radar range", "radarRange", 10f, 120f);
        toggle(o, "Crosshair dot", "crosshair");
        slider(o, "Max distance", "maxDist", 20f, 400f);
        LinearLayout s = card("SYNC");
        slider(s, "Display sync (ms)", "lat", -100f, 100f);
        slider(s, "FOV scale", "fovScale", 0.7f, 1.3f);
        toggle(s, "FOV is horizontal", "fovH");
        slider(s, "Box height", "boxH", 1.2f, 2.5f);
        note(s, "Boxes run AHEAD of the view when you turn: move Display sync lower (negative). Boxes lag behind: raise it. Off-centre: FOV scale / horizontal.");
    }

    private void tabCamera() {
        LinearLayout t = card("3RD PERSON");
        toggle(t, "Enable", "cam3p");
        slider(t, "Distance", "cam3pDist", 0.5f, 6f);
        slider(t, "Height", "cam3pHeight", -0.5f, 2f);
        note(t, "Moves the real render camera back off the pivot, not an overlay trick. Local-space offset, no collision check -- it will clip into walls/geometry up close. Status below.");
        Snap s = Model.snap;
        LinearLayout st = card("STATUS");
        String c3 = "not reported";
        int i = s.info.indexOf("cam3p=");
        if (i >= 0) { int e = s.info.indexOf(' ', i); c3 = s.info.substring(i + 6, e < 0 ? s.info.length() : e); }
        note(st, "cam3p: " + c3);
        note(st, "no_local_camera means the game hasn't spawned your camera yet (menu/loading); ok means it's actively moved.");
    }

    private void tabMisc() {
        LinearLayout a = card("STATUS");
        Snap s = Model.snap;
        note(a, "core: " + (s.ok ? "ok" : s.status));
        note(a, "players: " + s.players.length + "   fov: " + s.fov);
        note(a, "package: " + Cfg.pkg);
        if (!s.info.isEmpty()) note(a, s.info);
        LinearLayout b = card("ABOUT");
        note(b, "Astral.exe. The chams-style fill is drawn on top of the screen; the real models are not recoloured.");
    }

    private void tabConfig() {
        LinearLayout a = card("CONFIG");
        button(a, "Save", () -> { Cfg.save(c); h.changed(); });
        button(a, "Load", () -> { Cfg.load(c); h.changed(); rebuild(); });
        button(a, "Reset to defaults", () -> { Cfg.reset(); h.changed(); rebuild(); });
        button(a, "Unload", h::unload);
    }
}
